# ZEE AI BOT

A futuristic, mobile-friendly Gemini-powered AI chat website.

## Stack
- HTML/CSS/JavaScript frontend
- Vercel serverless API endpoint
- Google Gemini API via the official `@google/genai` SDK
- Browser localStorage for guest chat history

## Important security rule
Never put your Gemini API key in `public/index.html`, `public/app.js`, or any file committed to GitHub. The key belongs in the deployment environment as `GEMINI_API_KEY`.

## Deploy with GitHub + Vercel
1. Create a GitHub repository, e.g. `zee-ai-bot`.
2. Upload this entire project.
3. Import the repository into Vercel.
4. In Vercel Project Settings → Environment Variables, create `GEMINI_API_KEY` and paste your Gemini API key.
5. Redeploy.
6. Open the Vercel URL and test the Chat page.

GitHub Pages alone can host the static frontend, but it cannot run the server-side API endpoint. Use a serverless host such as Vercel for the `/api/chat` backend.

## Local development
Create `.env.local` from `.env.example`, put your key in it, then run:

```bash
npm install
npx vercel dev
```

## Next upgrades
- Real user accounts
- Database-backed chat history
- Voice input/output
- Image upload and vision
- File uploads
- Admin dashboard
- Rate limiting and abuse protection
- Custom domain
