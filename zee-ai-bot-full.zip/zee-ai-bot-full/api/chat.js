import { GoogleGenAI } from '@google/genai';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed.' });
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: 'Gemini API key is not configured on the server.' });
  }

  try {
    const { message, previousInteractionId } = req.body || {};
    const cleanMessage = String(message || '').trim();

    if (!cleanMessage) {
      return res.status(400).json({ error: 'Please enter a message.' });
    }
    if (cleanMessage.length > 8000) {
      return res.status(400).json({ error: 'Message is too long. Please keep it under 8,000 characters.' });
    }

    const client = new GoogleGenAI({ apiKey });
    const interaction = await client.interactions.create({
      model: 'gemini-3.8-flash',
      input: cleanMessage,
      ...(previousInteractionId ? { previous_interaction_id: previousInteractionId } : {}),
      system_instruction: `You are ZEE AI BOT, a friendly, smart, respectful AI assistant.\n\nYour style:\n- Be helpful, clear, natural and concise unless the user asks for detail.\n- You can help with coding, school, business ideas, writing, explanations and everyday questions.\n- Never claim to be human.\n- If you are unsure, say so instead of inventing facts.\n- When giving code, make it practical and explain where it belongs.\n- Treat the user's privacy seriously.\n- The product name is ZEE AI BOT.`
    });

    return res.status(200).json({
      reply: interaction.output_text || 'I received your message, but I could not produce a text response.',
      interactionId: interaction.id
    });
  } catch (error) {
    console.error('Gemini error:', error);
    return res.status(500).json({ error: 'ZEE AI is temporarily unavailable. Check your Gemini API key and deployment settings.' });
  }
}
